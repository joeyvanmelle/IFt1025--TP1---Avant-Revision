//Joey Van Melle : 20145502
//Tanguy Bulliard : 20126144

//Classe contenant les listes index�es
public class Index {
	
	public ListeCle listeCle = new ListeCle();
	
	//Fonction qui permet d'ins�rer un noeud dans l'index
	public void inserer(String cle, String valeur, int freq) {
		ListeCle.Cle node = listeCle.getHead();
		while (node != null) {
			//Si la Cle existe d�j�, on ajoute le noeud � la Cle.
			if (node.getCleName().equals(cle)) {
				node.getListeValeur().inserer(valeur, freq);
				return;
			}
			node = node.getNext();
		}
		//Sinon, on ajoute une nouvelle Cle
		listeCle.addCle(cle, new ListeValeur(valeur, freq));
	}
}
