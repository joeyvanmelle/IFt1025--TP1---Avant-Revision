//Joey Van Melle : 20145502
//Tanguy Bulliard : 20126144

//Liste qui se retrouve dans les Cles de ListeCle
public class ListeValeur {
	
	
	private ListObject head = null;
	
	//Cr�ation des noeuds de la Liste
	static class ListObject {
		
		private ListObjectObject object;
		private ListObject next = null;
		
		//Constructeur du noeud
		public ListObject(String valeur, int freq) {
			object = new ListObjectObject(valeur, freq);
		}
		
		//Getters et Setters des noeuds
		public String getValeur() {
			return object.getValeur();
		}
		
		public int getFreq() {
			return object.getFreq();
		}
		
		public void setFreq(int freq) {
			object.setFreq(freq);
		}
		
		public ListObject getNext() {
			return next;
		}
		
		public void setNext(ListObject next) {
			this.next = next;
		}
	}
	
	//Getters et Setters de la liste
	public ListObject getHead() {
		return head;
	}
	
	public void setHead(ListObject head) {
		this.head = head;
	}
	
	//Constructeurs de la liste
	public ListeValeur() {
		
	}
	public ListeValeur(String valeur, int freq) {
		head = new ListObject(valeur, freq);
	}
	
	//Fonction pour retirer un noeud
	public void removeNode(ListObject listObject) {
		
		ListObject node = head;
		if (node == null) return;
		ListObject previousNode = precedent(listObject, head);
		if (previousNode != null) {
			previousNode.setNext(listObject.getNext());
		} else {
			head = head.getNext();
		}
	}
	
	//Fonction pour ajouter un noeud
	public void inserer(String valeur, int freq) {
		ListObject listObject = head;
		//Si la valeur du noeud existe d�j�, on augmente la fr�quence
		while (listObject != null) {
			if (listObject.getValeur().equals(valeur)) {
				listObject.setFreq(listObject.getFreq() + freq);
				return;
			}
			listObject = listObject.next;
		}
		//sinon on ajoute un noeud
		listObject = new ListObject(valeur, freq);
		insert(listObject, head);
	}
	
	//Fonction qui retourne le noeud pr�c�dent. Les arguments sont le noeud
	//pour lequel on cherche le pr�c�dent et le premier noeud de la liste
	public ListObject precedent(ListObject listObject, ListObject startNode) {
		if (listObject.equals(head)) return null;
		if (startNode.getNext().equals(listObject)) return startNode;
		else return precedent(listObject, startNode.getNext());
	}
	
	/* Fonction pour ajouter un noeud dans un ordre d�croissant des fr�quences
	 * Le premier argument est le noeud � ins�rer et le deuxi�me argument est le premier noeud de la liste
	   o� on veut ins�rer le noeud */
	public void insert(ListObject node, ListObject startNode) {
		
		//Si la fr�quence est sup�rieure au prochain noeud, on place le noeud
		if (node.getFreq() >= startNode.getFreq()) {
			if (startNode.equals(head)) {
				node.setNext(head);
				head = node;
			} else {
				ListObject precedent = precedent(startNode, head);
				node.setNext(startNode);
				precedent.setNext(node);
			}
		//Sinon on passe au noeud suivant, on ajoute le noeud � la fin s'il ne reste plus de noeud	
		} else if (startNode.getNext() == null) {
			startNode.setNext(node);
		} else {
			insert(node, startNode.getNext());
		}
	}
	
	//Fonction pour trier la Liste
	//l'argument est le premier noeud � trier
	public void sort(ListObject startNode)  {
		ListObject next = startNode.getNext();
		
		//Si la liste est vide, la m�thode est termin�e
		if (next == null) return;
		
		//Si un noeud n'est pas � sa place, on le retire et on le replace dans la partie d�j� tri�e
		if (startNode.getFreq() < next.getFreq()) {
			if (startNode.equals(head)) {
				startNode.setNext(next.getNext());
				next.setNext(startNode);
				head = next;
			} else  {
				precedent(startNode, head).setNext(next);
				startNode.setNext(null);
				insert(startNode, head);
				sort(next);
			}
			
		//Si le noeud est � sa place, on passe au suivant
		} else {
			sort(next);
		}
	}
	
	//m�thode qui lance la fonction sort sur toute la liste
	public void trierFreq() {
		if (head.getNext() == null) return;
		sort(head);
	}
}

