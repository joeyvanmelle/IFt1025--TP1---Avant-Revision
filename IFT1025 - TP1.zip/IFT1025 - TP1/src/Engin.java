//Joey Van Melle : 20145502
//Tanguy Bulliard : 20126144

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Engin {
	
	Index index = new Index();
	Index indexInv = new Index();
	
	//Fonction qui lance le programme
	public static void main(String[] args) {
		Engin engin = new Engin();
		engin.program();
			
	}
	
	//Fonction qui permet � l'utilisateur d'int�ragir avec le programme.
	public void program() {
		
		//On pr�sente les choix � l'utilisateur
		System.out.println();
		printDots();
		System.out.println("Choisisser votre commande");
		printDots();
		System.out.println("indexer *nom du fichier/repertoire*");
		System.out.println("inverser");
		System.out.println("afficher");
		System.out.println("rechercher *requete*");
		Scanner scanner = new Scanner(System.in);
		String answer = scanner.nextLine();
		
		//On effectue une fonction bas�e sur la commande de l'utilisateur
		String shortAnswer = answer.substring(0,3);
		switch(shortAnswer) {
			case "ind" :
				answer = answer.substring(7, answer.length());
				String space = Character.toString(answer.charAt(0));
				int countSpaces = 0;
				while (space.equals(" ")) {
					countSpaces += 1;
					space = Character.toString(answer.charAt(countSpaces));
				}
				answer = answer.substring(countSpaces, answer.length());
				indexer(answer);
				break;
				
			case "inv" :
				indexerInv();
				break;
				
			case "aff" :
				afficher();
				break;
				
			case "rec" :
				answer = answer.substring(7, answer.length());
				space = Character.toString(answer.charAt(0));
				countSpaces = 0;
				while (space.equals(" ")) {
					countSpaces += 1;
					space = Character.toString(answer.charAt(countSpaces));
				}
				answer = answer.substring(countSpaces, answer.length());
				rechercher(answer);
				break;
				
			default:
				System.out.println("Error: You must enter a command.");
				scanner.close();
				return;
		}
		
		//On repr�sente le menu afin que l'utilisateur puisse entrer la commande suivante
		program();
		scanner.close();
	}
	
	//M�thode qui fait appara�tre une ligne pointill�e dans la console (pour la pr�sentation)
	public void printDots() {
		System.out.println("--------------------------------------------------------------------------------------------------------------------");
	}
	
	//m�thode qui appelle la indexe un ou plusieurs fichiers
	public void indexer(String source) {
		File file = new File(source);
		
		//Si la source est un r�pertoire, on lit tout les fichiers du r�pertoire
		if (file.isDirectory()) {
			File[] files = file.listFiles();
			if (files.length == 0) { System.out.println("Error: the folder is empty");};
			for (File f : files) {
				indexFile(f);
			}
			
		//Sinon, on lit le fichier tout simplement
		} else if (file.isFile()) {
			indexFile(file);
		} else {
			System.out.println("Error: path does not lead to a file");
		}
	}
	
	//M�thode qui remplis l'index d'engin en lisant un fichier
	public void indexFile(File file ) {
		try {
			Scanner fileScanner = new Scanner(file);
			//On ajoute chaque mot du fichier dans l'index
			while (fileScanner.hasNext()) {
				String word = fileScanner.next();
				String c = String.valueOf(word.charAt(word.length()-1));
				if (c.equals(".") || c.equals("!")|| c.equals("?")|| c.equals(":")|| c.equals(";")) {
					word = word.substring(0, word.length() - 1);
				}
				index.inserer(file.getName(), word, 1);
			}
			fileScanner.close();
		} catch (IOException e) {
			System.err.println("File error" + e.toString());
		}
	}
	
	//M�thode qui cr�e un index invers� � partir de l'index form� en lisant les documents
	public void indexerInv() {
		ListeCle.Cle cle = index.listeCle.getHead();
		while (cle != null) {
			ListeValeur.ListObject node = cle.getListeValeur().getHead();
			while (node != null) {
				indexInv.inserer(node.getValeur(), cle.getCleName(), node.getFreq());
				node = node.getNext();
			}
			cle = cle.getNext();
		}
		cle = indexInv.listeCle.getHead();
		while (cle != null) {
			cle.getListeValeur().trierFreq();
			cle = cle.getNext();
		}
	}
	
	//M�thode qui affiche l'index et l'index invers� dans la console
	public void afficher() {
		System.out.println();
		printDots();
		System.out.println("Index :");
		printDots();
		display(index);
		System.out.println();
		printDots();
		System.out.println("IndexInv :");
		printDots();
		display(indexInv);
	}
	
	//M�thode qui pr�sente les divers �l�ments d'un index dans la console
	public void display(Index index) {
		ListeCle.Cle cle = index.listeCle.getHead();
		while (cle != null) {
			String word = cle.getCleName();
			String line = enlarge(word, 25 - word.length());
			line = line + " | ";
			ListeValeur.ListObject node = cle.getListeValeur().getHead();
			while (node != null) {
				word = String.valueOf(node.getFreq()) + " " + node.getValeur();
				word = enlarge(word, 20 - word.length());
				line = line + word;
				node = node.getNext();
			}
			System.out.println(line);
			cle = cle.getNext();
		}
	}
		
	//M�thode qui permet d'�largir les mots afin qu'ils aient la m�me taille
	public String enlarge(String string, int j) {
		for (int i = 0; i < j; i++) {
			string = string + " ";
		}
		return string;
	}
	
	//M�thode qui recherche tout les mots de la requ�te et qui retourne une liste contenant les
	//documents qui poss�dent ces mots.
	public ListeValeur rechercher(String requete) {

		String[] tokenArray = requete.split("\\s");
			
		// On v�rifie que la requete n'est pas vide
		if (tokenArray.length > 0) {
			
			//On trouve la cle correspondant au premier mot de la requete
			ListeValeur output = findTokenInList(tokenArray, 0);
						
			//Si le premier mot de la requ�te n'existe pas dans les documents, retourner output vide
			if (output.getHead() == null) {
				System.out.println();
				printDots();
				System.out.println("R�sultats");
				printDots();
				System.out.println("Aucun document n'a �t� trouv�.");
				return output;
			}
				
			//V�rifier que les autres mots de la requ�te se trouve dans les documents de output
			//Augmenter les fr�quences si c'est le cas.
			output = updateOutput(tokenArray, output);
			output.trierFreq();
			Index index = new Index();
			index.listeCle.addCle("Documents correspondants:", output);
			Engin engin = new Engin();
			engin.index = index;
			System.out.println();
			printDots();
			System.out.println("R�sultats");
			printDots();
			engin.display(index);
			return output;
		} else {
			System.out.println("La requ�te est vide");
			return new ListeValeur();
		}	
	}	
	
	//Fonction qui trouve une cle dont le nom est correspondant � l'�l�ment i d'un tableau.
	public ListeValeur findTokenInList(String[] tokenArray, int i) {
		String token = tokenArray[i];
		ListeCle.Cle cle = indexInv.listeCle.getHead();
		while (cle != null) {
			if (token.equals(cle.getCleName())) {
				return cle.getListeValeur();
			}
			cle = cle.getNext();
		}
		return new ListeValeur();
	}
	
	//Fonction qui retire les documents superflus de la r�ponse output
	public ListeValeur updateOutput(String[] tokenArray, ListeValeur output) {
		for (int i = 1; i < tokenArray.length; i++) {
			
			//Trouver la liste du token
			ListeValeur tokenList = findTokenInList(tokenArray, i);
			
			//Augmenter la fr�quence des documents dont les mots du token actuel et des token pr�c�dents
			//sont pr�sent.
			ListeValeur.ListObject outputNode = output.getHead();
			while (outputNode != null) {
				ListeValeur.ListObject tokenNode = tokenList.getHead();
				boolean isCommon = false;
				while (tokenNode != null)  {
					if (tokenNode.getValeur().equals(outputNode.getValeur())) {
						outputNode.setFreq(outputNode.getFreq() + tokenNode.getFreq());
						isCommon = true;
					}
					
					tokenNode = tokenNode.getNext();
				}
				if (!isCommon) {
					output.removeNode(outputNode);
				}
				outputNode = outputNode.getNext();
			}
		}
		return output;
	}
	
}
