//Joey Van Melle : 20145502
//Tanguy Bulliard : 20126144

//Objet se retrouvant � l'int�rieur des noeuds de ListeValeur

public class ListObjectObject {
	private int freq;
	private String valeur;
	
	public ListObjectObject(String valeur, int freq) {
		this.freq = freq;
		this.valeur = valeur;
	}
	
	//Getters et setters
	public int getFreq() {
		return freq;
	}
	
	public void setFreq(int freq) {
		this.freq = freq;
	}

	public String getValeur() {
		return valeur;
	}
	
	public void setValeur(String valeur) {
		this.valeur = valeur;
	}
}
