//Joey Van Melle : 20145502
//Tanguy Bulliard : 20126144

//Liste se retrouvant dans Index
public class ListeCle {
	
	private Cle head = null;
	
	//Cr�ation des noeuds
	static class Cle {
		// *Note: ici, nous avons utilis� le nom cleName plut�t que cle pour �vit� les confusions
		private String cleName; 
		private Cle next = null;
		private ListeValeur listeValeur;
		
		//Constructeur
		public Cle(String cleName, ListeValeur listeValeur) {
			this.cleName = cleName;
			this.listeValeur = listeValeur;		
		}
		
		//Getters et Setters pour les noeuds;
		public String getCleName() {
			return cleName;
		}
		
		public ListeValeur getListeValeur() {
			return listeValeur;
		}

		public Cle getNext() {
			return next;
		}

		public void setNext(Cle next) {
			this.next = next;
		}
	}
	
	//Getters pour la Liste
	public Cle getHead() {
		return head;
	}
	
	//Fonction qui ajoute une cle � la liste
	public void addCle(String cleName, ListeValeur listeValeur) {
		Cle cle = new Cle(cleName, listeValeur);
		cle.setNext(head);
		head = cle;
	}
}
